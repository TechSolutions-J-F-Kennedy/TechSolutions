const $=s=>document.querySelector(s),L=localStorage;
const ESTADOS=['Pendiente','Yendo','En proceso','Finalizado'];
const PEDIDO={id:'#1042',servicio:'Reparación de PC',cliente:'Juan Pérez',telefono:'+598 99 123 456',ubicacion:'Av. Brasil 1234, Montevideo',horario:'14:00 - 16:00',materiales:'Cables, cinta aislante, tester, fuente 12V',detalle:'La PC no enciende luego de un corte de luz. Revisar fuente y placa madre.'};
const OTRAS=[{t:'Revisión de tablero · Sra. López',e:'Pendiente'},{t:'Instalación de luminarias · Taller Sur',e:'Pendiente'},{t:'Cambio de llave térmica · Ruiz',e:'Finalizado'}];
const user=()=>L.user||'Pepe',estado=()=>L.estado||'Pendiente';
const CLS={'Pendiente':'pending','Yendo':'progress','En proceso':'progress','Finalizado':'success'};
const st=e=>`<span class="status ${CLS[e]}">${e}</span>`;
const ORDER={index:-1,pendientes:0,herramientas:1,inicio:2,pedido_actual:2.5,perfil:3,chat:4};
const pg=u=>((u||location.pathname).split('/').pop().replace('.html',''))||'index';
const cur=ORDER[pg()];
if(!L.user&&pg()!='index')location.href='index.html';
const prev=parseFloat(sessionStorage.idx);
if(!isNaN(prev)&&cur<prev)document.documentElement.classList.add('back');
sessionStorage.idx=cur;
function go(u){document.querySelector('.app').classList.add(ORDER[pg(u)]<cur?'outB':'outF');setTimeout(()=>location.href=u,240)}
document.addEventListener('click',e=>{const a=e.target.closest('a[href]');if(a&&a.getAttribute('href').endsWith('.html')){e.preventDefault();go(a.getAttribute('href'))}});
document.addEventListener('DOMContentLoaded',()=>{
if(!document.body.classList.contains('login')){
const l=[['pendientes','clipboard-list','Tareas'],['herramientas','wrench','Herram.'],['inicio','house','Inicio'],['perfil','user','Perfil'],['chat','message-circle','Chat']];
const p=pg()=='pedido_actual'?'inicio':pg();
document.body.insertAdjacentHTML('beforeend','<nav>'+l.map(x=>`<a href="${x[0]}.html" class="${x[0]==p?'on':''}"><i data-lucide="${x[1]}"></i>${x[2]}</a>`).join('')+'</nav>')}
if(window.lucide)lucide.createIcons()});
